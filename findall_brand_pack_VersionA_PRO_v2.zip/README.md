# findAll — Brand Pack (Version A)

Generated from the approved **master vector** (step 1).

## Master
- assets/logo/findall_logo_master.svg

## Mark (All + underline)
- assets/mark/findall_mark_all_underline.svg

## Favicons
- assets/favicon/favicon.svg
- assets/favicon/favicon.ico
- assets/favicon/favicon_*.png

## HTML snippet
```html
<link rel="icon" href="assets/favicon/favicon.ico">
<link rel="icon" type="image/svg+xml" href="assets/favicon/favicon.svg">
<link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/favicon_180.png">
<img src="assets/logo/findall_logo_master.svg" alt="findAll" style="max-width:520px;">
```
